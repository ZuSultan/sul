function myFunc() {
	let modal = document.getElementById('entrance');

	let btn = document.getElementById("right-block-first");

	let span = document.getElementsByClassName("block-enter")[0];

	btn.onclick = function() {
	  modal.style.display = "block";
	}

	span.onclick = function() {
	  modal.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modal) {
	    modal.style.display = "none";
	  }
	}
}


function myFuncSecond() {
	let modal = document.getElementById('second-menu');

	let btn = document.getElementById("right-block-second");

	let span = document.getElementsByClassName("close")[0];

	btn.onclick = function() {
	  modal.style.display = "block";
	}

	span.onclick = function() {
	  modal.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modal) {
	    modal.style.display = "none";
	  }
	}
}



function myFuncThird() {
	let fin = document.getElementById('entrance');

	let modal = document.getElementById('checkin');

	let btn = document.getElementById("second-link");

	let span = document.getElementsByClassName("block-enter-twoo")[0];

	btn.onclick = function() {
	  modal.style.display = "block";
	  fin.style.display = "none"
	}

	span.onclick = function() {
	  modal.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modal) {
	    modal.style.display = "none";
	  }
	}
}

function myFuncFour() {
	document.getElementById("map").classList.toggle("active");	
}

myFunc();

myFuncSecond();

myFuncThird();